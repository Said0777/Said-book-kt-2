'use strict';

const Database = require('../Database');
const { hashPassword, verifyPassword } = require('../utils/password');

class User {
  constructor(db = Database.getInstance()) {
    this.db = db;
  }

  findByLogin(login) {
    return this.db.get('SELECT * FROM users WHERE login = ?', [login]);
  }

  findById(id) {
    return this.db.get('SELECT * FROM users WHERE id = ?', [id]);
  }

  create({ login, password, fio, phone, email, role = 'reader' }) {
    const { hash, salt } = hashPassword(password);
    const result = this.db.run(
      `INSERT INTO users (login, password_hash, password_salt, fio, phone, email, role)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [login, hash, salt, fio, phone, email, role]
    );
    return this.findById(Number(result.lastInsertRowid));
  }

  authenticate(login, password) {
    const user = this.findByLogin(login);
    if (!user) return null;
    const ok = verifyPassword(password, user.password_hash, user.password_salt);
    return ok ? user : null;
  }

  toPublic(user) {
    if (!user) return null;
    const { password_hash, password_salt, ...pub } = user;
    return pub;
  }
}

module.exports = User;
