'use strict';

const Database = require('../Database');
const Book = require('./Book');

/** Разрешённые переходы статусов заявки (конечный автомат) */
const STATUS_FLOW = {
  'Новая': ['Одобрена', 'Отклонена'],
  'Одобрена': ['Завершена'],
  'Завершена': [],
  'Отклонена': [],
};

class RequestModel {
  constructor(db = Database.getInstance()) {
    this.db = db;
    this.bookModel = new Book(db);
  }

  create({ userId, bookId, method }) {
    const book = this.bookModel.findById(bookId);
    if (!book) throw new Error('Помещение/экземпляр не найден');
    if (book.status !== 'Имеется') throw new Error('Книга недоступна для выдачи');

    const result = this.db.run(
      `INSERT INTO requests (user_id, book_id, method, status) VALUES (?, ?, ?, 'Новая')`,
      [userId, bookId, method]
    );
    this.bookModel.setStatus(bookId, 'Отсутствует');
    return this.findById(Number(result.lastInsertRowid));
  }

  findById(id) {
    return this.db.get(
      `SELECT r.*, b.title, b.author, b.code, b.image, u.fio, u.login
       FROM requests r
       JOIN books b ON b.id = r.book_id
       JOIN users u ON u.id = r.user_id
       WHERE r.id = ?`,
      [id]
    );
  }

  findByUser(userId) {
    return this.db.all(
      `SELECT r.*, b.title, b.author, b.code, b.image,
              (SELECT COUNT(*) FROM reviews rv WHERE rv.request_id = r.id) AS has_review
       FROM requests r JOIN books b ON b.id = r.book_id
       WHERE r.user_id = ? ORDER BY r.created_at DESC`,
      [userId]
    );
  }

  findAll({ status = 'all' } = {}) {
    let sql = `SELECT r.*, b.title, b.author, b.code, u.fio, u.login, u.phone
               FROM requests r
               JOIN books b ON b.id = r.book_id
               JOIN users u ON u.id = r.user_id
               WHERE 1=1`;
    const params = [];
    if (status !== 'all') {
      sql += ' AND r.status = ?';
      params.push(status);
    }
    sql += ' ORDER BY r.created_at DESC';
    return this.db.all(sql, params);
  }

  updateStatus(id, newStatus) {
    const req = this.findById(id);
    if (!req) throw new Error('Заявка не найдена');
    const allowed = STATUS_FLOW[req.status] || [];
    if (!allowed.includes(newStatus)) {
      throw new Error(`Нельзя перевести заявку из статуса «${req.status}» в «${newStatus}»`);
    }
    this.db.run(
      `UPDATE requests SET status = ?, updated_at = datetime('now') WHERE id = ?`,
      [newStatus, id]
    );
    if (newStatus === 'Завершена' || newStatus === 'Отклонена') {
      this.bookModel.setStatus(req.book_id, 'Имеется');
    }
    return this.findById(id);
  }

  counts() {
    return this.db.all(
      `SELECT status, COUNT(*) AS n FROM requests GROUP BY status`
    );
  }
}

module.exports = RequestModel;
