'use strict';

const Database = require('../Database');

class Review {
  constructor(db = Database.getInstance()) {
    this.db = db;
  }

  create({ requestId, userId, bookId, rating, text }) {
    const existing = this.db.get('SELECT id FROM reviews WHERE request_id = ?', [requestId]);
    if (existing) throw new Error('Отзыв по этой заявке уже оставлен');

    const result = this.db.run(
      `INSERT INTO reviews (request_id, user_id, book_id, rating, text) VALUES (?, ?, ?, ?, ?)`,
      [requestId, userId, bookId, rating, text || '']
    );
    return this.db.get('SELECT * FROM reviews WHERE id = ?', [Number(result.lastInsertRowid)]);
  }

  findByBook(bookId) {
    return this.db.all(
      `SELECT rv.*, u.fio FROM reviews rv JOIN users u ON u.id = rv.user_id
       WHERE rv.book_id = ? ORDER BY rv.created_at DESC`,
      [bookId]
    );
  }
}

module.exports = Review;
