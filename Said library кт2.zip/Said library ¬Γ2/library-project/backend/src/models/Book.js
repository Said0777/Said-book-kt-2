'use strict';

const Database = require('../Database');

class Book {
  constructor(db = Database.getInstance()) {
    this.db = db;
  }

  findAll({ search = '', genre = 'all', type = 'all', status = 'all' } = {}) {
    let sql = 'SELECT *, condition_ AS condition FROM books WHERE 1=1';
    const params = [];
    if (search) {
      sql += ' AND (title LIKE ? OR author LIKE ? OR code LIKE ?)';
      const like = `%${search}%`;
      params.push(like, like, like);
    }
    if (genre !== 'all') {
      sql += ' AND genre LIKE ?';
      params.push(`%${genre}%`);
    }
    if (type !== 'all') {
      sql += ' AND type = ?';
      params.push(type);
    }
    if (status !== 'all') {
      sql += ' AND status = ?';
      params.push(status);
    }
    sql += ' ORDER BY id';
    return this.db.all(sql, params);
  }

  findById(id) {
    return this.db.get('SELECT *, condition_ AS condition FROM books WHERE id = ?', [id]);
  }

  findByCode(code) {
    return this.db.get('SELECT *, condition_ AS condition FROM books WHERE code = ?', [code]);
  }

  setStatus(id, status) {
    this.db.run('UPDATE books SET status = ? WHERE id = ?', [status, id]);
  }

  count() {
    return this.db.get('SELECT COUNT(*) AS n FROM books').n;
  }
}

module.exports = Book;
