'use strict';

const express = require('express');
const router = express.Router();

const auth = require('../controllers/authController');
const books = require('../controllers/bookController');
const requests = require('../controllers/requestController');
const { requireAuth, requireRole } = require('../middleware/auth');

/* Аутентификация */
router.post('/auth/register', auth.register);
router.post('/auth/login', auth.login);
router.post('/auth/logout', auth.logout);
router.get('/auth/me', requireAuth, auth.me);

/* Каталог книг */
router.get('/books', books.list);
router.get('/books/:id', books.getOne);

/* Заявки читателя */
router.post('/requests', requireAuth, requests.createRequest);
router.get('/requests/mine', requireAuth, requests.myRequests);
router.post('/reviews', requireAuth, requests.leaveReview);

/* Панель администратора */
router.get('/admin/requests', requireAuth, requireRole('admin', 'librarian'), requests.adminList);
router.patch('/admin/requests/:id', requireAuth, requireRole('admin', 'librarian'), requests.adminUpdateStatus);

module.exports = router;
