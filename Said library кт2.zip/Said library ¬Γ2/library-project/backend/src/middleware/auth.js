'use strict';

const crypto = require('node:crypto');

/** Простое серверное хранилище токенов сессий (для учебного проекта) */
class SessionStore {
  constructor() {
    this.sessions = new Map(); // token -> userId
  }
  create(userId) {
    const token = crypto.randomBytes(24).toString('hex');
    this.sessions.set(token, userId);
    return token;
  }
  resolve(token) {
    return this.sessions.get(token) || null;
  }
  destroy(token) {
    this.sessions.delete(token);
  }
}

const sessionStore = new SessionStore();

function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  const userId = token ? sessionStore.resolve(token) : null;
  if (!userId) {
    return res.status(401).json({ error: 'Требуется авторизация' });
  }
  req.userId = userId;
  next();
}

function requireRole(...roles) {
  return (req, res, next) => {
    const User = require('../models/User');
    const user = new User().findById(req.userId);
    if (!user || !roles.includes(user.role)) {
      return res.status(403).json({ error: 'Недостаточно прав' });
    }
    req.currentUser = user;
    next();
  };
}

module.exports = { sessionStore, requireAuth, requireRole };
