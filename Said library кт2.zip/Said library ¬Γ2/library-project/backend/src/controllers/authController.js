'use strict';

const User = require('../models/User');
const { validateRegistration } = require('../utils/validators');
const { sessionStore } = require('../middleware/auth');

const userModel = new User();

function register(req, res) {
  const { login, password, fio, phone, email } = req.body;

  const { valid, errors } = validateRegistration({ login, password, fio, phone, email });
  if (!valid) {
    return res.status(400).json({ error: 'Ошибка валидации', fields: errors });
  }
  if (userModel.findByLogin(login)) {
    return res.status(409).json({ error: 'Этот логин уже занят' });
  }

  const user = userModel.create({ login, password, fio, phone, email, role: 'reader' });
  const token = sessionStore.create(user.id);
  res.status(201).json({ token, user: userModel.toPublic(user) });
}

function login(req, res) {
  const { login, password } = req.body;
  if (!login || !password) {
    return res.status(400).json({ error: 'Введите логин и пароль' });
  }
  const user = userModel.authenticate(login, password);
  if (!user) {
    return res.status(401).json({ error: 'Неверный логин или пароль' });
  }
  const token = sessionStore.create(user.id);
  res.json({ token, user: userModel.toPublic(user) });
}

function logout(req, res) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (token) sessionStore.destroy(token);
  res.json({ ok: true });
}

function me(req, res) {
  const user = userModel.findById(req.userId);
  res.json({ user: userModel.toPublic(user) });
}

module.exports = { register, login, logout, me };
