'use strict';

const Book = require('../models/Book');
const Review = require('../models/Review');

const bookModel = new Book();
const reviewModel = new Review();

function list(req, res) {
  const { search = '', genre = 'all', type = 'all', status = 'all' } = req.query;
  res.json({ books: bookModel.findAll({ search, genre, type, status }) });
}

function getOne(req, res) {
  const book = bookModel.findById(Number(req.params.id));
  if (!book) return res.status(404).json({ error: 'Не найдено' });
  const reviews = reviewModel.findByBook(book.id);
  res.json({ book, reviews });
}

module.exports = { list, getOne };
