'use strict';

const RequestModel = require('../models/RequestModel');
const Review = require('../models/Review');

const requestModel = new RequestModel();
const reviewModel = new Review();

function createRequest(req, res) {
  const { bookId, method } = req.body;
  if (!bookId || !['hall', 'home', 'reserve'].includes(method)) {
    return res.status(400).json({ error: 'Укажите книгу и способ получения' });
  }
  try {
    const request = requestModel.create({ userId: req.userId, bookId: Number(bookId), method });
    res.status(201).json({ request });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}

function myRequests(req, res) {
  res.json({ requests: requestModel.findByUser(req.userId) });
}

function leaveReview(req, res) {
  const { requestId, rating, text } = req.body;
  const request = requestModel.findById(Number(requestId));
  if (!request || request.user_id !== req.userId) {
    return res.status(404).json({ error: 'Заявка не найдена' });
  }
  if (request.status !== 'Завершена') {
    return res.status(400).json({ error: 'Отзыв доступен только после завершения выдачи' });
  }
  try {
    const review = reviewModel.create({
      requestId: request.id,
      userId: req.userId,
      bookId: request.book_id,
      rating: Number(rating),
      text,
    });
    res.status(201).json({ review });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}

/* ── Администратор ── */
function adminList(req, res) {
  const { status = 'all' } = req.query;
  res.json({ requests: requestModel.findAll({ status }), counts: requestModel.counts() });
}

function adminUpdateStatus(req, res) {
  const { status } = req.body;
  try {
    const request = requestModel.updateStatus(Number(req.params.id), status);
    res.json({ request });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}

module.exports = { createRequest, myRequests, leaveReview, adminList, adminUpdateStatus };
