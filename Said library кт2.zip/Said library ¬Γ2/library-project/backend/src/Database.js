'use strict';

const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const fs = require('node:fs');

/**
 * Database — единая точка доступа к БД (паттерн Singleton).
 * Инкапсулирует подключение и создание схемы.
 * Использует node:sqlite (встроен в Node.js 22+, не требует
 * интернета и внешних библиотек — важно для офлайн-сдачи экзамена).
 */
class Database {
  static #instance = null;

  constructor(filePath) {
    if (Database.#instance) {
      return Database.#instance;
    }
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

    this.connection = new DatabaseSync(filePath);
    this.connection.exec('PRAGMA foreign_keys = ON;');
    this.#createSchema();
    Database.#instance = this;
  }

  static getInstance(filePath = path.join(__dirname, '..', 'data', 'library.db')) {
    if (!Database.#instance) {
      new Database(filePath);
    }
    return Database.#instance;
  }

  #createSchema() {
    this.connection.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        login         TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        password_salt TEXT NOT NULL,
        fio           TEXT NOT NULL,
        phone         TEXT NOT NULL,
        email         TEXT NOT NULL,
        role          TEXT NOT NULL DEFAULT 'reader' CHECK(role IN ('reader','librarian','admin')),
        created_at    TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS books (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        code        TEXT NOT NULL UNIQUE,
        title       TEXT NOT NULL,
        author      TEXT NOT NULL,
        publisher   TEXT,
        year        INTEGER,
        genre       TEXT,
        type        TEXT NOT NULL CHECK(type IN ('Общая','Учебная','Художественная')),
        status      TEXT NOT NULL DEFAULT 'Имеется' CHECK(status IN ('Имеется','Отсутствует','На реставрации')),
        condition_  TEXT NOT NULL DEFAULT 'Нормальная' CHECK(condition_ IN ('Новая','Нормальная','Ветхая')),
        hall        TEXT,
        rack        TEXT,
        shelf       INTEGER,
        image       TEXT
      );

      CREATE TABLE IF NOT EXISTS requests (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        book_id     INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
        method      TEXT NOT NULL CHECK(method IN ('hall','home','reserve')),
        status      TEXT NOT NULL DEFAULT 'Новая' CHECK(status IN ('Новая','Одобрена','Завершена','Отклонена')),
        created_at  TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at  TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE TABLE IF NOT EXISTS reviews (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        request_id  INTEGER NOT NULL UNIQUE REFERENCES requests(id) ON DELETE CASCADE,
        user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        book_id     INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
        rating      INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
        text        TEXT,
        created_at  TEXT NOT NULL DEFAULT (datetime('now'))
      );

      CREATE INDEX IF NOT EXISTS idx_requests_user ON requests(user_id);
      CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
      CREATE INDEX IF NOT EXISTS idx_books_status ON books(status);
    `);
  }

  exec(sql) {
    return this.connection.exec(sql);
  }

  /** SELECT, возвращающий массив строк */
  all(sql, params = []) {
    const stmt = this.connection.prepare(sql);
    return stmt.all(...params);
  }

  /** SELECT, возвращающий одну строку */
  get(sql, params = []) {
    const stmt = this.connection.prepare(sql);
    return stmt.get(...params);
  }

  /** INSERT/UPDATE/DELETE */
  run(sql, params = []) {
    const stmt = this.connection.prepare(sql);
    return stmt.run(...params);
  }
}

module.exports = Database;
