'use strict';

/**
 * Правила валидации полей регистрации:
 *  - логин: латиница и цифры, минимум 6 символов
 *  - пароль: минимум 8 символов
 *  - ФИО: кириллица и пробелы (минимум 2 слова)
 *  - телефон: 8(XXX)XXX-XX-XX
 *  - email: стандартный формат электронной почты
 */
const RULES = {
  login: /^[A-Za-z0-9]{6,}$/,
  password: /^.{8,}$/,
  fio: /^[А-ЯЁа-яё]+(?:\s[А-ЯЁа-яё]+){1,2}$/,
  phone: /^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/,
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
};

function validateRegistration({ login, password, fio, phone, email }) {
  const errors = {};
  if (!RULES.login.test(login || '')) {
    errors.login = 'Логин: латиница и цифры, минимум 6 символов';
  }
  if (!RULES.password.test(password || '')) {
    errors.password = 'Пароль: минимум 8 символов';
  }
  if (!RULES.fio.test(fio || '')) {
    errors.fio = 'ФИО: только кириллица и пробелы (Фамилия Имя Отчество)';
  }
  if (!RULES.phone.test(phone || '')) {
    errors.phone = 'Телефон в формате 8(XXX)XXX-XX-XX';
  }
  if (!RULES.email.test(email || '')) {
    errors.email = 'Введите корректный email';
  }
  return { valid: Object.keys(errors).length === 0, errors };
}

module.exports = { RULES, validateRegistration };
