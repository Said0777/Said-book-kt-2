'use strict';

const Database = require('./Database');
const { hashPassword } = require('./utils/password');

const db = Database.getInstance();

const books = [
  ["ОЛЦ1-1-00001/01","История всего и ничего","Сухих А.Р.","Параграф",1997,"Биография","Общая","Имеется","Новая","ОЛ","Ц1",1,"images/book1.jpg"],
  ["ОЛЦ1-1-00001/02","История всего и ничего","Сухих А.Р.","Параграф",1997,"Биография","Общая","Имеется","Нормальная","ОЛ","Ц1",1,"images/book2.jpg"],
  ["НЛУ1-3-00002/01","Бизнес аналитика в экономике","Белой Д.В., Низкий Е.В.","ЛитраМакс",2022,"Научная, Методическая","Учебная","Отсутствует","Нормальная","НЛ","У1",3,"images/book4.jpg"],
  ["НЛУ1-3-00002/02","Бизнес аналитика в экономике","Белой Д.В., Низкий Е.В.","ЛитраМакс",2022,"Научная, Методическая","Учебная","Имеется","Новая","НЛ","У1",3,"images/book5.jpg"],
  ["ОЛП1-2-00003/01","Там куда тянет","Самоходов Е.В.","Параграф",2006,"Роман, Драма","Общая","Имеется","Нормальная","ОЛ","П1",2,"images/book7.jpg"],
  ["ХЛП2-1-00004/01","Сборник. Том 2","Белой Д.В.","ЛитраМакс",2015,"Повести, Рассказы","Художественная","Отсутствует","Нормальная","ХЛ","П2",1,"images/book10.jpg"],
  ["ХЛП2-1-00005/01","Обо всём","Ульянова И.С.","ЛитраМакс",2000,"Стихи, Проза","Художественная","Имеется","Нормальная","ХЛ","П2",1,"images/book11.jpg"],
  ["НЛЦ2-3-00006/01","Машинное обучение","Ульянова И.С., Синицына К.В.","Общий доступ",2023,"Научная","Учебная","Имеется","Новая","НЛ","Ц2",3,"images/book12.jpg"],
];

function seedBooks() {
  if (db.get('SELECT COUNT(*) AS n FROM books').n > 0) return;
  for (const b of books) {
    db.run(
      `INSERT INTO books (code,title,author,publisher,year,genre,type,status,condition_,hall,rack,shelf,image)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      b
    );
  }
  console.log(`Добавлено книг: ${books.length}`);
}

function seedUsers() {
  const seedUser = (login, password, fio, phone, email, role) => {
    if (db.get('SELECT id FROM users WHERE login=?', [login])) return;
    const { hash, salt } = hashPassword(password);
    db.run(
      `INSERT INTO users (login,password_hash,password_salt,fio,phone,email,role) VALUES (?,?,?,?,?,?,?)`,
      [login, hash, salt, fio, phone, email, role]
    );
    console.log(`Создан пользователь: ${login} (${role})`);
  };

  // Фиксированный аккаунт администратора (панель администратора)
  seedUser('Admin2027', 'Demo7777', 'Администратов Админ Админович', '8(900)000-00-00', 'admin@library.local', 'admin');
  // Демонстрационный читатель
  seedUser('IvanovII01', 'Pa$$w0rd1', 'Иванов Иван Иванович', '8(900)123-45-67', 'ivanov@example.com', 'reader');
}

seedBooks();
seedUsers();
console.log('Готово.');
