'use strict';

const express = require('express');
const path = require('node:path');
const apiRoutes = require('./src/routes');

// Инициализация БД (создаёт схему при первом запуске)
require('./src/Database').getInstance();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Раздача фронтенда как статики
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// REST API
app.use('/api', apiRoutes);

app.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});
