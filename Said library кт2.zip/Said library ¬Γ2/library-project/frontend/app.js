/* ── КОНФИГ / СОСТОЯНИЕ ── */
const API = '/api';
let authToken = localStorage.getItem('token') || null;
let currentUser = null;
let currentBooks = [];
let selectedBookId = null;
let selectedRequestId = null;
let selectedRating = 0;
let currentAdminStatus = 'all';

/* ── HELPER: запрос к API ── */
async function api(path, { method = 'GET', body } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (authToken) headers['Authorization'] = 'Bearer ' + authToken;
  const res = await fetch(API + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'Ошибка запроса'), { data });
  return data;
}

/* ── НАВИГАЦИЯ ── */
function navigateTo(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(page + '-page').classList.add('active');

  if (page === 'home') {
    document.getElementById('video-hero').style.display = '';
    document.body.classList.add('on-hero');
    loadBooks();
  } else {
    document.getElementById('video-hero').style.display = 'none';
    document.body.classList.remove('on-hero');
  }

  if (page === 'about') loadAboutStats();
  if (page === 'profile') loadProfile();
  if (page === 'admin') loadAdminRequests();

  window.scrollTo({ top: 0, behavior: 'smooth' });
}
window.navigateTo = navigateTo;

/* ── ВХОД / РЕГИСТРАЦИЯ ── */
function switchLoginTab(tab) {
  const isLogin = tab === 'login';
  document.getElementById('login-tab').classList.toggle('active', isLogin);
  document.getElementById('register-tab').classList.toggle('active', !isLogin);
  document.getElementById('login-form').style.display = isLogin ? 'block' : 'none';
  document.getElementById('register-form').style.display = isLogin ? 'none' : 'block';
}
window.switchLoginTab = switchLoginTab;

function scrollToCatalog() {
  setTimeout(() => document.querySelector('.books-grid')?.scrollIntoView({ behavior: 'smooth' }), 100);
}
window.scrollToCatalog = scrollToCatalog;

function setLoggedIn(user, token) {
  currentUser = user;
  authToken = token;
  localStorage.setItem('token', token);
  document.getElementById('auth-buttons').style.display = 'none';
  const um = document.getElementById('user-menu');
  um.style.display = 'flex';
  document.getElementById('user-name').textContent = user.fio.split(' ')[0];
  const isAdmin = user.role === 'admin' || user.role === 'librarian';
  document.getElementById('admin-link').style.display = isAdmin ? '' : 'none';
  document.getElementById('my-requests-link').style.display = isAdmin ? 'none' : '';
}

function setLoggedOut() {
  currentUser = null;
  authToken = null;
  localStorage.removeItem('token');
  document.getElementById('auth-buttons').style.display = '';
  document.getElementById('user-menu').style.display = 'none';
  document.getElementById('admin-link').style.display = 'none';
  document.getElementById('my-requests-link').style.display = 'none';
}

async function restoreSession() {
  if (!authToken) return;
  try {
    const { user } = await api('/auth/me');
    setLoggedIn(user, authToken);
  } catch {
    setLoggedOut();
  }
}

document.getElementById('login-form').onsubmit = async e => {
  e.preventDefault();
  const login = document.getElementById('login-login').value.trim();
  const password = document.getElementById('login-password').value;
  if (!login || !password) { showNotification('Заполните все поля', 'error'); return; }
  try {
    const { user, token } = await api('/auth/login', { method: 'POST', body: { login, password } });
    setLoggedIn(user, token);
    showNotification('Добро пожаловать, ' + user.fio.split(' ')[0] + '! 👋');
    navigateTo(user.role === 'admin' || user.role === 'librarian' ? 'admin' : 'profile');
  } catch (err) {
    showNotification(err.message, 'error');
    document.getElementById('login-password').value = '';
  }
};

/* Валидация регистрации на клиенте (дублирует серверную) */
const CLIENT_RULES = {
  login: /^[A-Za-z0-9]{6,}$/,
  password: /^.{8,}$/,
  fio: /^[А-ЯЁа-яё]+(?:\s[А-ЯЁа-яё]+){1,2}$/,
  phone: /^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/,
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
};

function validateRegForm() {
  const vals = {
    fio: document.getElementById('reg-fio').value.trim(),
    login: document.getElementById('reg-login').value.trim(),
    password: document.getElementById('reg-password').value,
    phone: document.getElementById('reg-phone').value.trim(),
    email: document.getElementById('reg-email').value.trim(),
  };
  const msgs = {
    fio: 'ФИО: кириллица и пробелы (Фамилия Имя Отчество)',
    login: 'Логин: латиница и цифры, от 6 символов',
    password: 'Пароль: минимум 8 символов',
    phone: 'Формат: 8(XXX)XXX-XX-XX',
    email: 'Некорректный email',
  };
  let ok = true;
  for (const field of Object.keys(CLIENT_RULES)) {
    const valid = CLIENT_RULES[field].test(vals[field]);
    document.getElementById('err-' + field).textContent = valid ? '' : msgs[field];
    if (!valid) ok = false;
  }
  return { ok, vals };
}

document.getElementById('register-form').onsubmit = async e => {
  e.preventDefault();
  const { ok, vals } = validateRegForm();
  if (!ok) return;
  try {
    const { user, token } = await api('/auth/register', { method: 'POST', body: vals });
    setLoggedIn(user, token);
    showNotification('Добро пожаловать, ' + user.fio.split(' ')[0] + '! 🎉');
    navigateTo('profile');
  } catch (err) {
    if (err.data && err.data.fields) {
      for (const [field, msg] of Object.entries(err.data.fields)) {
        const el = document.getElementById('err-' + field);
        if (el) el.textContent = msg;
      }
    }
    showNotification(err.message, 'error');
  }
};

document.getElementById('logout-btn').onclick = async () => {
  try { await api('/auth/logout', { method: 'POST' }); } catch {}
  setLoggedOut();
  showNotification('До свидания!');
  navigateTo('home');
};

/* ── КАТАЛОГ ── */
async function loadBooks() {
  const search = document.getElementById('search')?.value || '';
  const genre = document.getElementById('genre')?.value || 'all';
  const type = document.getElementById('type')?.value || 'all';
  const status = document.getElementById('status')?.value || 'all';
  const qs = new URLSearchParams({ search, genre, type, status });
  const { books } = await api('/books?' + qs.toString());
  currentBooks = books;
  renderBooks();
}

const fallbackImages = [
  "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400",
  "https://images.unsplash.com/photo-1532012197267-da84d127e765?w=400",
  "https://images.unsplash.com/photo-1621351183012-e2f9972dd9bf?w=400",
];

function renderBooks() {
  const grid = document.getElementById('books-grid');
  if (!grid) return;
  if (currentBooks.length === 0) {
    grid.innerHTML = '<div class="empty-state">Ничего не найдено по заданным фильтрам</div>';
    return;
  }
  grid.innerHTML = '';
  currentBooks.forEach((book, i) => {
    const sClass = book.status === 'Имеется' ? 'available' : book.status === 'Отсутствует' ? 'unavailable' : 'repair';
    const cClass = book.condition === 'Новая' ? 'new' : book.condition === 'Ветхая' ? 'old' : 'normal';
    const ok = book.status === 'Имеется' && book.condition !== 'Ветхая';
    const card = document.createElement('div');
    card.className = 'book-card';
    card.style.animationDelay = (i * 0.04) + 's';
    card.innerHTML = `
      <div class="book-image">
        <img src="${book.image}" alt="${book.title}" onerror="this.src='${fallbackImages[i % 3]}'">
      </div>
      <div class="book-info">
        <div class="book-code">${book.code}</div>
        <div class="book-title">${book.title}</div>
        <div class="book-author">${book.author}</div>
        <div class="book-meta">
          <span class="badge ${sClass}">${book.status}</span>
          <span class="badge ${cClass}">${book.condition}</span>
        </div>
        <div class="book-details">
          <div class="detail-row"><span class="detail-label">Издатель</span><span class="detail-value">${book.publisher || '—'}</span></div>
          <div class="detail-row"><span class="detail-label">Год</span><span class="detail-value">${book.year || '—'}</span></div>
          <div class="detail-row"><span class="detail-label">Жанр</span><span class="detail-value">${book.genre || '—'}</span></div>
          <div class="detail-row"><span class="detail-label">Тип</span><span class="detail-value">${book.type}</span></div>
          <div class="detail-row"><span class="detail-label">Место</span><span class="detail-value">Зал ${book.hall}, стеллаж ${book.rack}, полка ${book.shelf}</span></div>
        </div>
        <button class="issue-btn" data-id="${book.id}" ${!ok ? 'disabled' : ''}>
          ${ok ? 'Запросить выдачу' : 'Недоступна'}
        </button>
      </div>`;
    card.querySelector('.book-image').style.cursor = 'pointer';
    card.querySelector('.book-image').onclick = () => openBookPage(book.id);
    card.querySelector('.book-title').style.cursor = 'pointer';
    card.querySelector('.book-title').onclick = () => openBookPage(book.id);
    grid.appendChild(card);
  });
}

document.getElementById('search')?.addEventListener('input', debounce(loadBooks, 300));
document.getElementById('genre')?.addEventListener('change', loadBooks);
document.getElementById('type')?.addEventListener('change', loadBooks);
document.getElementById('status')?.addEventListener('change', loadBooks);

function debounce(fn, ms) {
  let t;
  return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

document.addEventListener('click', e => {
  if (e.target.classList.contains('issue-btn') && !e.target.disabled) {
    if (!authToken) { showNotification('Сначала войдите в систему', 'error'); navigateTo('login'); return; }
    openBuyModal(Number(e.target.dataset.id));
  }
});

/* ── СТРАНИЦА КНИГИ ── */
async function openBookPage(id) {
  const { book, reviews } = await api('/books/' + id);
  const ok = book.status === 'Имеется' && book.condition !== 'Ветхая';
  const prices = { 'Общая': '150 ₽ / мес', 'Учебная': '200 ₽ / мес', 'Художественная': '120 ₽ / мес' };
  const sClass = book.status === 'Имеется' ? 'available' : book.status === 'Отсутствует' ? 'unavailable' : 'repair';
  const cClass = book.condition === 'Новая' ? 'new' : book.condition === 'Ветхая' ? 'old' : 'normal';
  const reviewsHtml = reviews.length
    ? reviews.map(r => `<div class="detail-row" style="display:block;padding:.6rem 0;"><b style="color:white">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</b> <span style="color:var(--text-2)">— ${r.fio}</span><br><span style="color:var(--text-2);font-size:.85rem">${r.text || ''}</span></div>`).join('')
    : '<div style="color:var(--text-3);font-size:.85rem">Отзывов пока нет</div>';

  document.getElementById('book-detail-content').innerHTML = `
    <div class="book-detail">
      <div class="book-detail-cover">
        <img src="${book.image}" alt="${book.title}" onerror="this.src='${fallbackImages[book.id % 3]}'">
      </div>
      <div class="book-detail-info">
        <div class="book-code" style="margin-bottom:.4rem">${book.code}</div>
        <h1>${book.title}</h1>
        <div class="author-line">Автор: ${book.author}</div>
        <div class="book-meta" style="margin-bottom:1.2rem">
          <span class="badge ${sClass}">${book.status}</span>
          <span class="badge ${cClass}">${book.condition}</span>
        </div>
        <table class="book-detail-table">
          <tr><td>Издатель</td><td>${book.publisher || '—'}</td></tr>
          <tr><td>Год издания</td><td>${book.year || '—'}</td></tr>
          <tr><td>Жанр</td><td>${book.genre || '—'}</td></tr>
          <tr><td>Тип</td><td>${book.type}</td></tr>
          <tr><td>Расположение</td><td>Зал ${book.hall}, стеллаж ${book.rack}, полка ${book.shelf}</td></tr>
        </table>
        <div class="price-block">
          <div class="price-label">Стоимость абонемента</div>
          <div class="price-val">${prices[book.type] || '150 ₽ / мес'}</div>
        </div>
        <button class="book-buy-btn" ${!ok ? 'disabled' : ''} onclick="${authToken ? `openBuyModal(${book.id})` : `navigateTo('login')`}">
          ${ok ? 'Оформить выдачу' : 'Книга недоступна'}
        </button>
        <div class="section-title" style="font-size:1.05rem;margin-top:1.8rem;margin-bottom:.8rem;">Отзывы</div>
        ${reviewsHtml}
      </div>
    </div>`;
  navigateTo('book');
}
window.openBookPage = openBookPage;

/* ── МОДАЛ ЗАЯВКИ ── */
function openBuyModal(bookId) {
  selectedBookId = bookId;
  const book = currentBooks.find(b => b.id === bookId);
  document.getElementById('buy-modal-title').textContent = book ? `«${book.title}»` : '';
  document.getElementById('buy-modal').classList.add('open');
}
window.openBuyModal = openBuyModal;
function closeBuyModal() { document.getElementById('buy-modal').classList.remove('open'); }
window.closeBuyModal = closeBuyModal;

async function confirmBuy() {
  const method = document.getElementById('buy-method').value;
  try {
    await api('/requests', { method: 'POST', body: { bookId: selectedBookId, method } });
    closeBuyModal();
    showNotification('✅ Заявка отправлена на рассмотрение!');
    loadBooks();
  } catch (err) {
    showNotification(err.message, 'error');
  }
}
window.confirmBuy = confirmBuy;

/* ── ПРОФИЛЬ / МОИ ЗАЯВКИ ── */
async function loadProfile() {
  if (!currentUser) return;
  document.getElementById('profile-avatar').textContent = '👤';
  document.getElementById('profile-fullname').textContent = currentUser.fio;
  document.getElementById('profile-role-text').textContent = 'Читатель';
  document.getElementById('profile-login-val').textContent = currentUser.login;
  document.getElementById('profile-phone-val').textContent = currentUser.phone;
  document.getElementById('profile-email-val').textContent = currentUser.email;

  const { requests } = await api('/requests/mine');
  document.getElementById('profile-req-count').textContent = requests.length;
  const list = document.getElementById('my-requests-list');
  if (requests.length === 0) {
    list.innerHTML = '<div class="empty-state">Заявок пока нет — оформите выдачу книги в каталоге</div>';
    return;
  }
  list.innerHTML = requests.map(r => `
    <div class="request-card">
      <img src="${r.image}" onerror="this.src='${fallbackImages[r.id % 3]}'">
      <div class="request-info">
        <div class="request-title">${r.title}</div>
        <div class="request-meta">${r.author} · ${r.code} · заявка от ${formatDate(r.created_at)}</div>
      </div>
      <span class="status-pill status-${r.status}">${r.status}</span>
      ${r.status === 'Завершена'
        ? (r.has_review
            ? `<span style="font-size:.8rem;color:var(--text-3)">Отзыв оставлен</span>`
            : `<button class="review-btn" onclick="openReviewModal(${r.id}, '${escapeQ(r.title)}')">Оставить отзыв</button>`)
        : ''}
    </div>
  `).join('');
}

function formatDate(s) {
  if (!s) return '';
  return new Date(s.replace(' ', 'T') + 'Z').toLocaleDateString('ru-RU');
}
function escapeQ(s) { return String(s).replace(/'/g, "\\'"); }

function openReviewModal(requestId, title) {
  selectedRequestId = requestId;
  selectedRating = 0;
  document.querySelectorAll('#star-rating span').forEach(s => s.classList.remove('active'));
  document.getElementById('review-text').value = '';
  document.getElementById('review-modal-title').textContent = `«${title}»`;
  document.getElementById('review-modal').classList.add('open');
}
window.openReviewModal = openReviewModal;
function closeReviewModal() { document.getElementById('review-modal').classList.remove('open'); }
window.closeReviewModal = closeReviewModal;

document.querySelectorAll('#star-rating span').forEach(star => {
  star.addEventListener('click', () => {
    selectedRating = Number(star.dataset.v);
    document.querySelectorAll('#star-rating span').forEach(s => s.classList.toggle('active', Number(s.dataset.v) <= selectedRating));
  });
});

async function submitReview() {
  if (!selectedRating) { showNotification('Поставьте оценку', 'error'); return; }
  try {
    await api('/reviews', { method: 'POST', body: { requestId: selectedRequestId, rating: selectedRating, text: document.getElementById('review-text').value.trim() } });
    closeReviewModal();
    showNotification('Спасибо за отзыв! ⭐');
    loadProfile();
  } catch (err) {
    showNotification(err.message, 'error');
  }
}
window.submitReview = submitReview;

/* ── АДМИН-ПАНЕЛЬ ── */
document.getElementById('admin-tabs').addEventListener('click', e => {
  const tab = e.target.closest('.admin-tab');
  if (!tab) return;
  document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
  tab.classList.add('active');
  currentAdminStatus = tab.dataset.status;
  loadAdminRequests();
});

async function loadAdminRequests() {
  if (!currentUser || !(currentUser.role === 'admin' || currentUser.role === 'librarian')) return;
  const { requests } = await api('/admin/requests?status=' + encodeURIComponent(currentAdminStatus));
  const body = document.getElementById('admin-requests-body');
  if (requests.length === 0) {
    body.innerHTML = `<tr><td colspan="7"><div class="empty-state">Заявок нет</div></td></tr>`;
    return;
  }
  const methodLabels = { hall: 'Читальный зал', home: 'Домой', reserve: 'Бронь' };
  body.innerHTML = requests.map(r => `
    <tr>
      <td>#${r.id}</td>
      <td>${r.title}<br><span style="color:var(--text-3);font-size:.78rem">${r.code}</span></td>
      <td>${r.fio}<br><span style="color:var(--text-3);font-size:.78rem">${r.login}</span></td>
      <td>${r.phone}</td>
      <td>${methodLabels[r.method] || r.method}</td>
      <td><span class="status-pill status-${r.status}">${r.status}</span></td>
      <td><div class="admin-actions">${adminActionButtons(r)}</div></td>
    </tr>
  `).join('');
}

function adminActionButtons(r) {
  if (r.status === 'Новая') {
    return `<button class="admin-btn approve" onclick="adminSetStatus(${r.id},'Одобрена')">Одобрить</button>
            <button class="admin-btn reject" onclick="adminSetStatus(${r.id},'Отклонена')">Отклонить</button>`;
  }
  if (r.status === 'Одобрена') {
    return `<button class="admin-btn complete" onclick="adminSetStatus(${r.id},'Завершена')">Завершить</button>`;
  }
  return `<span style="color:var(--text-3);font-size:.78rem">—</span>`;
}

async function adminSetStatus(id, status) {
  try {
    await api('/admin/requests/' + id, { method: 'PATCH', body: { status } });
    showNotification('Статус заявки обновлён');
    loadAdminRequests();
  } catch (err) {
    showNotification(err.message, 'error');
  }
}
window.adminSetStatus = adminSetStatus;

/* ── О НАС: СТАТИСТИКА ── */
async function loadAboutStats() {
  const { books } = await api('/books');
  document.getElementById('about-total-books').textContent = books.length;
  document.getElementById('about-total-readers').textContent = '1500+';
}

/* ── УВЕДОМЛЕНИЯ ── */
function showNotification(msg, type = 'success') {
  const n = document.getElementById('notification');
  n.innerHTML = `<div class="notification ${type}">${msg}</div>`;
  setTimeout(() => n.innerHTML = '', 3000);
}

document.getElementById('buy-modal').addEventListener('click', e => { if (e.target === e.currentTarget) closeBuyModal(); });
document.getElementById('review-modal').addEventListener('click', e => { if (e.target === e.currentTarget) closeReviewModal(); });

/* ── СЧЁТЧИК ГЕРОЯ ── */
document.querySelectorAll('.count').forEach(el => {
  const target = +el.dataset.target;
  let c = 0; const step = target / 100;
  (function run() {
    c += step;
    if (c < target) { el.textContent = Math.floor(c).toLocaleString('ru-RU'); requestAnimationFrame(run); }
    else el.textContent = target.toLocaleString('ru-RU');
  })();
});

/* ── INIT ── */
(async function init() {
  await restoreSession();
  await loadBooks();
})();
