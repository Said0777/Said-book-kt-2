# ER-диаграмма БД «Городская библиотека»

```mermaid
erDiagram
    USERS ||--o{ REQUESTS : "оформляет"
    BOOKS ||--o{ REQUESTS : "запрашивается в"
    REQUESTS ||--o| REVIEWS : "может иметь"
    USERS ||--o{ REVIEWS : "оставляет"
    BOOKS ||--o{ REVIEWS : "получает"

    USERS {
        int id PK
        text login "уникальный, латиница+цифры, >=6"
        text password_hash
        text password_salt
        text fio "кириллица и пробелы"
        text phone "8(XXX)XXX-XX-XX"
        text email
        text role "reader | librarian | admin"
        text created_at
    }

    BOOKS {
        int id PK
        text code "уникальный шифр экземпляра"
        text title
        text author
        text publisher
        int year
        text genre
        text type "Общая|Учебная|Художественная"
        text status "Имеется|Отсутствует|На реставрации"
        text condition_ "Новая|Нормальная|Ветхая"
        text hall
        text rack
        int shelf
        text image
    }

    REQUESTS {
        int id PK
        int user_id FK
        int book_id FK
        text method "hall|home|reserve"
        text status "Новая|Одобрена|Завершена|Отклонена"
        text created_at
        text updated_at
    }

    REVIEWS {
        int id PK
        int request_id FK "уникальный - 1 отзыв на заявку"
        int user_id FK
        int book_id FK
        int rating "1..5"
        text text
        text created_at
    }
```

## Пояснение связей
- **USERS → REQUESTS** (1:N) — один пользователь может оформить много заявок на выдачу.
- **BOOKS → REQUESTS** (1:N) — один экземпляр книги может быть объектом многих заявок (в разное время).
- **REQUESTS → REVIEWS** (1:0..1) — отзыв можно оставить только по завершённой заявке, и только один раз.
- Жизненный цикл заявки: `Новая → Одобрена → Завершена` (либо `Новая → Отклонена`). Отзыв доступен только в статусе `Завершена`.

Файл экспортирован в Markdown/Mermaid, чтобы его можно было открыть в любой СУБД
с поддержкой Mermaid (DataGrip, DBeaver с плагином, draw.io) либо визуализировать
на https://mermaid.live/. Формат совместим с требованием задания «сохранить ER-диаграмму
в рабочей папке проекта в любом формате».
