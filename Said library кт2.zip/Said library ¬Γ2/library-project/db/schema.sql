-- Схема БД «Городская библиотека»
-- Рабочая версия использует SQLite (backend/src/Database.js).
-- Ниже — портируемый вариант для MySQL/PostgreSQL, если на экзамене
-- требуется конкретная СУБД с сервера.

CREATE TABLE users (
    id            INTEGER PRIMARY KEY AUTO_INCREMENT,
    login         VARCHAR(50)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    password_salt VARCHAR(64)  NOT NULL,
    fio           VARCHAR(150) NOT NULL,
    phone         VARCHAR(20)  NOT NULL,
    email         VARCHAR(150) NOT NULL,
    role          VARCHAR(20)  NOT NULL DEFAULT 'reader',
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_role CHECK (role IN ('reader','librarian','admin'))
);

CREATE TABLE books (
    id          INTEGER PRIMARY KEY AUTO_INCREMENT,
    code        VARCHAR(50) NOT NULL UNIQUE,
    title       VARCHAR(255) NOT NULL,
    author      VARCHAR(255) NOT NULL,
    publisher   VARCHAR(150),
    year        INTEGER,
    genre       VARCHAR(150),
    type        VARCHAR(30) NOT NULL,
    status      VARCHAR(30) NOT NULL DEFAULT 'Имеется',
    condition_  VARCHAR(30) NOT NULL DEFAULT 'Нормальная',
    hall        VARCHAR(10),
    rack        VARCHAR(10),
    shelf       INTEGER,
    image       VARCHAR(255),
    CONSTRAINT chk_type CHECK (type IN ('Общая','Учебная','Художественная')),
    CONSTRAINT chk_status CHECK (status IN ('Имеется','Отсутствует','На реставрации')),
    CONSTRAINT chk_cond CHECK (condition_ IN ('Новая','Нормальная','Ветхая'))
);

CREATE TABLE requests (
    id          INTEGER PRIMARY KEY AUTO_INCREMENT,
    user_id     INTEGER NOT NULL,
    book_id     INTEGER NOT NULL,
    method      VARCHAR(20) NOT NULL,
    status      VARCHAR(20) NOT NULL DEFAULT 'Новая',
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    CONSTRAINT chk_method CHECK (method IN ('hall','home','reserve')),
    CONSTRAINT chk_req_status CHECK (status IN ('Новая','Одобрена','Завершена','Отклонена'))
);

CREATE TABLE reviews (
    id          INTEGER PRIMARY KEY AUTO_INCREMENT,
    request_id  INTEGER NOT NULL UNIQUE,
    user_id     INTEGER NOT NULL,
    book_id     INTEGER NOT NULL,
    rating      INTEGER NOT NULL,
    text        TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
    CONSTRAINT chk_rating CHECK (rating BETWEEN 1 AND 5)
);

CREATE INDEX idx_requests_user ON requests(user_id);
CREATE INDEX idx_requests_status ON requests(status);
CREATE INDEX idx_books_status ON books(status);
